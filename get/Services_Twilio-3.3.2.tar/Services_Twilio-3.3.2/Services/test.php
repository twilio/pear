<?php
require "Services/Twilio/Capability.php";

$accountSid = "AC123123";
$authToken = "secret";

$capability = new Services_Twilio_Capability($accountSid, $authToken);

$capability->disablePresenceEvents();

$token = $capability->generateToken();

