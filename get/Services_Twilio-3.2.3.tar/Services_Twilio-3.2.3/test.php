<?php

require "Services/Twilio.php";

$account = getenv("TWILIO_ACCOUNT_SID");
$token = getenv("TWILIO_AUTH_TOKEN");

$http = new Services_Twilio_TinyHttp("https://api.twilio.com",
									 array("debug" => true));

$client = new Services_Twilio($account, $token, "2010-04-01", $http);

foreach($client->account->calls->getIterator(0, 1, array("StartDate<" => "2010-04-01")) as $call) {
	// hey
}

//print json_encode(array("hey" => "you"));
$participant = $client->account->conferences
    ->get("CO123")->participants->get("PF123");


