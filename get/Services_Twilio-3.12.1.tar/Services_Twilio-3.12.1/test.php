<?php

var_dump(get_include_path());
