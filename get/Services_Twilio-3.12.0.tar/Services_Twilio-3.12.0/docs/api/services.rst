###############################
HTTP Helper Classes
###############################

**********************
The Twilio Rest Client
**********************

.. phpautoclass:: Services_Twilio
    :filename: ../Services/Twilio.php
    :members:

***********************
Twilio Rest Exceptions
***********************
.. phpautoclass:: Services_Twilio_RestException
    :filename: ../Services/Twilio/RestException.php
    :members:
