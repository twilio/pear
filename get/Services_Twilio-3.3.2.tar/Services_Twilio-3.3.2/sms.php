<?php

require 'Services/Twilio.php';

$client = new Services_Twilio('AC58f1e8f2b1c6b88ca90a012a4be0c279', 'b7c3f506c974791449ffe924ba57e5c2');
$accountList = $client->accounts->getIterator(0, 50, array());
echo $client->accounts->total;
//print_r($client->accounts);
foreach($accountList as $account) {
    print $account->sid;
}

