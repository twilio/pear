<?php

require('Services/Twilio.php');

$client = new Services_Twilio('AC58f1e8f2b1c6b88ca90a012a4be0c279',
    '2451e90f0e6fa27c6bea3f822d482ec9');
$client->http->debug = true;

$client->account->messages->sendMessage('+1 925-392-0364', '+19252717005', 'blah');
